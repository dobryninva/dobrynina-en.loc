<?php
require_once (dirname(dirname(__FILE__)) . '/seoroomitem.class.php');
class SEOroomItem_mysql extends SEOroomItem {}