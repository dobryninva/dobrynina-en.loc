<?php

$_lang['area_compiler_main'] = 'Main';

$_lang['setting_compiler_some_setting'] = 'Some setting';
$_lang['setting_compiler_some_setting_desc'] = 'This is description for some setting';