--------------------
3PC: Gallery
--------------------
Version: 0.1.0
Since: June 4th, 2010
Author: Shaun McCormick <shaun@modx.com>

--------------------

A Gallery system for your photos.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/splittingred/Gallery/issues