<?php
class MsieAccessPrice extends xPDOSimpleObject {}