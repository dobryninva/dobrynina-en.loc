-------------------------------------------------------
Extension: msImportExport for MODX Revolution 2.3.2-pl
-------------------------------------------------------
Version: 1.0.0-beta
Released: November 30, 2015
Since: November 30, 2015
Author: Prihod

Description
    msImportExport