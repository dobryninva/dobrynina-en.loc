<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'MsieAccessPrice',
    1 => 'MsieCron',
    2 => 'MsieHeadAlias',
    3 => 'MsiePresetsFields',
  ),
);