<?php
require_once (dirname(dirname(__FILE__)) . '/msieaccessprice.class.php');
class MsieAccessPrice_mysql extends MsieAccessPrice {}