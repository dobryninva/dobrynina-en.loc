<?php
include_once MODX_CORE_PATH . 'components/ms2gallery/processors/mgr/gallery/update.class.php';

class msImportExportGalleryUpdateProcessor extends msResourceFileUpdateProcessor
{

}

return 'msImportExportGalleryUpdateProcessor';