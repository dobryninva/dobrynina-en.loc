<?php

class msImportExportGetProcessor extends modObjectGetProcessor {
	public $languageTopics = array('msimportexport:default');
	public $classKey = 'MsiePresetsFields';
}
return 'msImportExportGetProcessor';