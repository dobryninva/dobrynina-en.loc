<?php
/**
 * Price Russian Lexicon Entries for msImportExport
 *
 * @package msimportexport
 * @subpackage lexicon
 */
$_lang['msie.download_price'] = 'Скачать прайс лист';
$_lang['msie.err.sig'] = 'Неверная сигнатура запроса';
$_lang['msie.err.timeout'] = 'Вы не можете скачивать прайс лист чаще %s сек.';