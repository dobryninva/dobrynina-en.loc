<?php
/**
 * Italian Lexicon Entries for recaptchav2
 *
 * @package recaptchav2
 * @subpackage lexicon
 *
 */
// EXAMPLE: $_lang[''] = '';
$_lang['recaptchav2.technical_error_message'] = 'Si è verificato un errore nell\'invio del modulo. Per cortesia utilizza uno dei contatti in questa pagina.';
$_lang['recaptchav2.recaptcha_error_message'] = 'Per favore spunta la checkbox nell\'immagine ReCaptcha.';
$_lang['recaptchav2.recaptchav3_error_message'] = 'Si è verificato un errore.';
