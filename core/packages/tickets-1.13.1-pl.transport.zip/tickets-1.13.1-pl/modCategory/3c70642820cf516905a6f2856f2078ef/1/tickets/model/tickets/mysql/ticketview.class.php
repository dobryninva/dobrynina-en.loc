<?php
require_once (dirname(__DIR__) . '/ticketview.class.php');
class TicketView_mysql extends TicketView {}