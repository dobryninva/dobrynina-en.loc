<?php
require_once (dirname(__DIR__) . '/tickettotal.class.php');
class TicketTotal_mysql extends TicketTotal {}