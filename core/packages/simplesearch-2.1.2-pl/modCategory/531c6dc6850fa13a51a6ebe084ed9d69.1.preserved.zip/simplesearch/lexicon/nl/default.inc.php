<?php
/**
 * English Default Topic for SimpleSearch
 *
 * @package simplesearch
 * @subpackage lexicon
 * @language en
 */
$_lang['simplesearch.no_results'] = 'Er zijn geen zoekresultaten. Gebruik meer algemene termen om meer resultaten te krijgen.';
$_lang['simplesearch.search'] = 'Zoeken';
$_lang['simplesearch.results_found'] = '[[+count]] resultaten gevonden voor "[[+text]]"';
$_lang['simplesearch.result_pages'] = 'Zoekresultaten pagina\'s:';
