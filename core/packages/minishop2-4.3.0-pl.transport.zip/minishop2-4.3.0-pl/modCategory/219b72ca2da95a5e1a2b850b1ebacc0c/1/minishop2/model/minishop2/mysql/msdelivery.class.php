<?php

require_once(dirname(__FILE__, 2) . '/msdelivery.class.php');

class msDelivery_mysql extends msDelivery
{
}
