<?php

require_once MODX_CORE_PATH . 'components/minishop2/processors/mgr/product/productlink/multiple.class.php';

class modMsProductLinkMultipleProcessor extends msProductLinkMultipleProcessor
{

}

return 'modMsProductLinkMultipleProcessor';