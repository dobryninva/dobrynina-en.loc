<?php

$_lang['mssetincart_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице';
$_lang['mssetincart_prop_showLog'] = 'Показывать дополнительную информацию о работе сниппета. Только для авторизованных в контексте "mgr"';

$_lang['mssetincart_prop_element'] = 'Имя сниппета для запуска.';
$_lang['mssetincart_prop_link'] = 'Идентификатор связи.';
$_lang['mssetincart_prop_master'] = 'Идентификатор главного продукта.';
$_lang['mssetincart_prop_where'] = 'Строка, закодированная в JSON, с дополнительными условиями выборки';
$_lang['mssetincart_prop_limit'] = 'Ограничение вывода';
$_lang['mssetincart_prop_tpl'] = 'Чанк оформления';
$_lang['mssetincart_prop_frontJs'] = 'Файл с javascript';
$_lang['mssetincart_prop_frontCss'] = 'Файл с css';
$_lang['mssetincart_prop_actionUrl'] = 'Url action.php';

$_lang['mssetincart_prop_setActive'] = 'Состояние активности продукта набора';
$_lang['mssetincart_prop_setInput'] = 'Тип поля связи подуктов набора';
$_lang['mssetincart_prop_setMode'] = 'Режим обработки продуктов набора';

