<?php


// header

$_lang['mssetincart_header_id'] = '<i class="icon icon-sort-numeric-desc"></i>';
$_lang['mssetincart_header_rid'] = '<i class="icon icon-folder-o"></i>';
$_lang['mssetincart_header_actions'] = '<i class="icon icon-cogs"></i>';

// tooltip

$_lang['mssetincart_tooltip_id'] = 'Id';
$_lang['mssetincart_tooltip_rid'] = 'Id ресурса';
$_lang['mssetincart_tooltip_type'] = 'Тип';

// fields

$_lang['mssetincart_id'] = 'Id';
$_lang['mssetincart_name'] = 'Имя';
$_lang['mssetincart_key'] = 'Ключ';

// tabs
