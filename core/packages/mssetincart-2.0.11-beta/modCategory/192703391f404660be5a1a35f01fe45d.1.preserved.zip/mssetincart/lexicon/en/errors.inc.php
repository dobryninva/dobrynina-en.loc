<?php

/* Errors */

$_lang['mssetincart_err_system'] = 'System error';
$_lang['mssetincart_err_unknown'] = 'Unknown error';