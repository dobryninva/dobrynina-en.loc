<?php

$_lang['mssetincart_prop_toPlaceholder'] = 'If not empty, the snippet will save output to placeholder with that name, instead of return it to screen';
$_lang['mssetincart_prop_showLog'] = 'Display additional information about snippet work. Only for authenticated in context "mgr".';

$_lang['mssetincart_prop_element'] = 'The name of the snippet to run.';
$_lang['mssetincart_prop_link'] = 'Id of link of goods.';
$_lang['mssetincart_prop_master'] = 'Id of the master product.';
$_lang['mssetincart_prop_where'] = 'A JSON-style expression of criteria to build any additional where clauses from';
$_lang['mssetincart_prop_limit'] = 'The number of results to limit';
$_lang['mssetincart_prop_tpl'] = 'The chunk tpl';
$_lang['mssetincart_prop_frontJs'] = 'Frontend scripts';
$_lang['mssetincart_prop_frontCss'] = 'Frontend styles';
$_lang['mssetincart_prop_actionUrl'] = 'Url action.php';

$_lang['mssetincart_prop_setActive'] = 'The status of the product\'s activity';
$_lang['mssetincart_prop_setInput'] = 'Type of communication field of set products';
$_lang['mssetincart_prop_setMode'] = 'Processing mode set of products';

