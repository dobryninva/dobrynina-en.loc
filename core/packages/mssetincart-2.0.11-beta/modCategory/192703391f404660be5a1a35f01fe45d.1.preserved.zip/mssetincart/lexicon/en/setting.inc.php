<?php

$_lang['area_mssetincart_main'] = 'Main';

$_lang['setting_mssetincart_allow_zero_cost'] = 'Allow zero product cost';
//$_lang['setting_mssetincart_allow_zero_cost_desc'] = 'Разрешить нулевую стоимость продукта в результате модификации.';

$_lang['setting_mssetincart_front_js'] = 'Frontend scripts';
//$_lang['setting_mssetincart_front_js_desc'] = 'Файл с javascript для подключения на фронтенде. ';

$_lang['setting_mssetincart_front_css'] = 'Frontend styles';
//$_lang['setting_mssetincart_front_css_desc'] = 'Файл с css для подключения на фронтенде. ';

$_lang['setting_mssetincart_working_templates'] = 'Working templates';
//$_lang['setting_mssetincart_working_templates_desc'] = 'Список id шаблонов через запятую, для которых нужно активировать наборы.';

$_lang['setting_mssetincart_number_format'] = 'Number format';
//$_lang['setting_mssetincart_number_format_desc'] = 'Укажите, как нужно форматировать числа функцией round(). Используется JSON строка с массивом для передачи 2х параметров: количество цифр после запятой, способ округления.';

$_lang['setting_mssetincart_tpl_order_info'] = 'The chunk order info';
//$_lang['setting_mssetincart_tpl_order_info_desc'] = 'Шаблон вывода дополнительной информации в поле "комментарий" заказа';
