<?php

$_lang['area_seoroom_main'] = 'Main';

$_lang['setting_seoroom_some_setting'] = 'Some setting';
$_lang['setting_seoroom_some_setting_desc'] = 'This is description for some setting';