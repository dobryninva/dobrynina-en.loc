<?php

/**
 * @package seoroom
 */
class SEOroomItem extends xPDOSimpleObject {
}