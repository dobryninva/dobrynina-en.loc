<?php

$_lang['seoroom_prop_limit'] = 'Ограничение вывода счетчиков на странице.';
$_lang['seoroom_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['seoroom_prop_sortBy'] = 'Поле сортировки.';
$_lang['seoroom_prop_sortDir'] = 'Направление сортировки.';
$_lang['seoroom_prop_tpl'] = 'Чанк оформления каждого ряда счетчиков.';
$_lang['seoroom_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
