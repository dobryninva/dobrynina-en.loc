<?php

$_lang['area_seoroom_main'] = 'Основные';

$_lang['setting_seoroom_some_setting'] = 'Какая-то настройка';
$_lang['setting_seoroom_some_setting_desc'] = 'Это описание для какой-то настройки';