<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'seoroom-1.0.6-beta/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'baaf4ac4e0a1248b9ab2ab49b3eb1808',
      'native_key' => 'seoroom',
      'filename' => 'modNamespace/23da2b2b1ffe0bd0fc12ff5e691895bb.vehicle',
      'namespace' => 'seoroom',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f13779657370483f1dec46cd87feb96f',
      'native_key' => 1,
      'filename' => 'modCategory/91e1c0c90f4e86b66929c1fb41f02b16.vehicle',
      'namespace' => 'seoroom',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7a502e74f5b4a185fe7fa6a4ef917ba8',
      'native_key' => 1,
      'filename' => 'modCategory/a60639b233672caf4903355cc7ccb054.vehicle',
      'namespace' => 'seoroom',
    ),
  ),
);