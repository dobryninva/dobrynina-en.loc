<?php

$_lang['area_comparison_main'] = 'Main';

$_lang['setting_comparison_frontend_css'] = 'Styles of frontend';
$_lang['setting_comparison_frontend_css_desc'] = 'Path to the file with styles. If you want to use your own styles - specify the path to it here, or clear and download them manually via the website template.';
$_lang['setting_comparison_frontend_js'] = 'Scripts of frontend';
$_lang['setting_comparison_frontend_js_desc'] = 'Path to the file with scripts. If you want to use your own scripts - specify the path to it here, or clear and download them manually via the website template.';