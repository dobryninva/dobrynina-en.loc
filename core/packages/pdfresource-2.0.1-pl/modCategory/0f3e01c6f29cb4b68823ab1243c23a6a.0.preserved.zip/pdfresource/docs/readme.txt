PDFResource
===========

PDFResource is a MODX Revolution extra that converts resources to PDF files
using mPDF (https://mpdf.github.io/).

Installation
------------
MODX Package Management

Documentation
-------------
http://jako.github.io/PDFResource/

GitHub Repository
-----------------
https://github.com/Jako/PDFResource
