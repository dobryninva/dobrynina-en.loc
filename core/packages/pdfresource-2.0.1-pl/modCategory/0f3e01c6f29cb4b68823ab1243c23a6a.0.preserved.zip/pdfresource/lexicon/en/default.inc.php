<?php
/**
 * Default Lexicon Entries for PDFResource
 *
 * @package pdfresource
 * @subpackage lexicon
 */
$_lang['pdfresource'] = 'PDFResource';
