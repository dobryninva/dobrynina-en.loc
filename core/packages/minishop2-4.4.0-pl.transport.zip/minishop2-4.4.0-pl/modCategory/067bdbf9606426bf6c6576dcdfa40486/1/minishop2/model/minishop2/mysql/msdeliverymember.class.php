<?php

require_once(dirname(__FILE__, 2) . '/msdeliverymember.class.php');

class msDeliveryMember_mysql extends msDeliveryMember
{
}
