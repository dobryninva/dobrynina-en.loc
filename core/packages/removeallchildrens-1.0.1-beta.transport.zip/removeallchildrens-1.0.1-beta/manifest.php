<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e225164b0deb9e4bddb1567fb811cce3',
      'native_key' => 'removeallchildrens',
      'filename' => 'modNamespace/9944effda1a68ac478f2a949e99d2d0f.vehicle',
      'namespace' => 'removeallchildrens',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8bd2df8424ac7bf91ddd8e757d256bf0',
      'native_key' => 1,
      'filename' => 'modCategory/e450b07c66a09ea0a61f09f07f4d05c4.vehicle',
      'namespace' => 'removeallchildrens',
    ),
  ),
);