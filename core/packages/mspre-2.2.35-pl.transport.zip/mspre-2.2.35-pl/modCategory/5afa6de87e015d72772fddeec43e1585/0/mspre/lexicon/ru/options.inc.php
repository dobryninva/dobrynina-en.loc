<?php
$_lang['mspre_header_tags'] = 'Теги';
$_lang['mspre_header_color'] = 'Цвета';
$_lang['mspre_header_size'] = 'Размеры';