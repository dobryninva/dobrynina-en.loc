<?php
$_lang['mspre_header_tags'] = 'Tags';
$_lang['mspre_header_color'] = 'Colors';
$_lang['mspre_header_size'] = 'Size';