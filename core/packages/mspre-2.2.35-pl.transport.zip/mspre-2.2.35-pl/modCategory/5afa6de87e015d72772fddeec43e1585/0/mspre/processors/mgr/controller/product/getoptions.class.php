<?php
include_once MODX_CORE_PATH.'components/minishop2/processors/mgr/product/getoptions.class.php';
class mspremsProductGetOptionsProcessor extends msProductGetOptionsProcessor{}
return 'mspremsProductGetOptionsProcessor';