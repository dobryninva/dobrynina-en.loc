<?php
/**
 * Default Russian Lexicon Entries for msPre
 *
 * @package mspre
 * @subpackage lexicon
 */
/*
 * transactions
 * */
