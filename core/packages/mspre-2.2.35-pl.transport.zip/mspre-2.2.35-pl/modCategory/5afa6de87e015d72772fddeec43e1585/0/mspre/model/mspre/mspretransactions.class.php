<?php
class mspreTransactions extends xPDOSimpleObject {}