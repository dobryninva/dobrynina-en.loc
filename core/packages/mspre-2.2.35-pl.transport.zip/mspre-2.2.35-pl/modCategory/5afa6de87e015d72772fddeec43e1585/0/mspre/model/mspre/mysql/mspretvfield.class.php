<?php
require_once (dirname(__DIR__) . '/mspretvfield.class.php');
class mspreTvField_mysql extends mspreTvField {}