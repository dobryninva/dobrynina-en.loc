<?php
include_once dirname(dirname(__FILE__)) . '/multiple.php';

/**
 * Multiple a msProduct
 */
class modmsMultipleProcessor extends modmsMultipleDefaultProcessor
{
}

return 'modmsMultipleProcessor';