<?php
require_once (dirname(__DIR__) . '/mspretransactions.class.php');
class mspreTransactions_mysql extends mspreTransactions {}