--------------------
seoTemplates
--------------------
Author: p1rate <pro-verstka@yandex.ru>
--------------------

Package for creating seо templates.