<?php
require_once (dirname(dirname(__FILE__)) . '/seotemplatesitem.class.php');
class seoTemplatesItem_mysql extends seoTemplatesItem {}