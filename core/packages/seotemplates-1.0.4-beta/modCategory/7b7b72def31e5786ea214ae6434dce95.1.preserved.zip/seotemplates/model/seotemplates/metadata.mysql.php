<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'seoTemplatesItem',
    1 => 'seoTemplatesField',
  ),
);