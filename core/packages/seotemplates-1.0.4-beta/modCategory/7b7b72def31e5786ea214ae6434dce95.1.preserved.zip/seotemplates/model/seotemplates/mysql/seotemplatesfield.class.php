<?php
require_once (dirname(dirname(__FILE__)) . '/seotemplatesfield.class.php');
class seoTemplatesField_mysql extends seoTemplatesField {}