<?php
class seoTemplatesField extends xPDOSimpleObject {}