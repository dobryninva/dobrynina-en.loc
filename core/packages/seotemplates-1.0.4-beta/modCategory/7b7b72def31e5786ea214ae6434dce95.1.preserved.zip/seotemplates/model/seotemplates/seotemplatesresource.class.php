<?php
class seoTemplatesResource extends xPDOSimpleObject {}