<?php

$_lang['area_seotemplates_main'] = 'Main';

$_lang['setting_seotemplates_placeholder_prefix'] = 'Prefix';
$_lang['setting_seotemplates_placeholder_prefix_desc'] = 'Prefix for placeholder fields, for example [[+ st_pagetitle]]';