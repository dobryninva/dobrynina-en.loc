<?php
$xpdo_meta_map['FileAttachMediaSource']= array (
  'package' => 'fileattach',
  'version' => '1.1',
  'extends' => 'modMediaSource',
  'tableMeta' => 
  array (
    'engine' => 'MyISAM',
  ),
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
