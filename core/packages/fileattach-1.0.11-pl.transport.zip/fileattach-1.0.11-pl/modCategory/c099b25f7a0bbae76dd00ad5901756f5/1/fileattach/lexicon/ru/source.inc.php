<?php

$_lang['fileattach.source_name'] = 'Присоединенные файлы';
$_lang['fileattach.source_desc'] = 'Отображает присоединенные файлы к ресурсам.';