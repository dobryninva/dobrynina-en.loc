<?php

$_lang['fileattach.prop_groups'] = 'Разрешить просмотр перечисленным группам';
$_lang['fileattach.prop_limit'] = 'Ограничение вывода файлов на странице.';
$_lang['fileattach.prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['fileattach.prop_sortBy'] = 'Поле сортировки.';
$_lang['fileattach.prop_sortDir'] = 'Направление сортировки.';
$_lang['fileattach.prop_tpl'] = 'Чанк оформления каждого ряда файлов.';
$_lang['fileattach.prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
$_lang['fileattach.prop_private'] = 'Закрытый режим дает скачать файл через идентификатор файла';
$_lang['fileattach.prop_resource'] = 'Показать файлы для документа с номером id';
$_lang['fileattach.prop_privateUrl'] = 'Форсировать использование обработчик скачиваний, что позволяет считать скачивания даже для открытых файлов';
$_lang['fileattach.prop_makeUrl'] = 'Создавать ссылку для скачивания файла';
$_lang['fileattach.prop_showSize'] = 'Получать размер файла';
$_lang['fileattach.prop_showHASH'] = 'Отображать хэш файла';
$_lang['fileattach.prop_showExt'] = 'Выделять расширение из названия файла';
