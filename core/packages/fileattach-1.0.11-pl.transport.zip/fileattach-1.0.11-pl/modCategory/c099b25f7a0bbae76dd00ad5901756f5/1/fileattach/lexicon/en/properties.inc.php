<?php

$_lang['fileattach.prop_groups'] = 'Allow view to listed groups';
$_lang['fileattach.prop_limit'] = 'The number of files to limit per page.';
$_lang['fileattach.prop_outputSeparator'] = 'A string to separate each row with.';
$_lang['fileattach.prop_sortBy'] = 'The field to sort by.';
$_lang['fileattach.prop_sortDir'] = 'The direction to sort by.';
$_lang['fileattach.prop_tpl'] = 'The chunk to use for each row of files.';
$_lang['fileattach.prop_toPlaceholder'] = 'If set, will output the content to the placeholder specified in this property, rather than outputting the content directly.';
$_lang['fileattach.prop_private'] = 'Private mode sets download through file id';
$_lang['fileattach.prop_resource'] = 'Show files for resource id';
$_lang['fileattach.prop_privateUrl'] = 'Force private url. Allows to count downloads even with open files';
$_lang['fileattach.prop_makeUrl'] = 'Generate URL for file download';
$_lang['fileattach.prop_showSize'] = 'Retrieve file size';
$_lang['fileattach.prop_showHASH'] = 'Show file hash';
$_lang['fileattach.prop_showExt'] = 'Extract file extension';
