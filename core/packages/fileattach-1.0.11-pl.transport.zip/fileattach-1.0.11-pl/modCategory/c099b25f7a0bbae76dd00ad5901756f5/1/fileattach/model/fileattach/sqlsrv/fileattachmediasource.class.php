<?php
require_once (dirname(__DIR__) . '/fileattachmediasource.class.php');
class FileAttachMediaSource_sqlsrv extends FileAttachMediaSource {}