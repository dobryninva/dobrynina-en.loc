<?php

$_lang['fileattach.source_name'] = 'Attached files';
$_lang['fileattach.source_desc'] = 'A source that lists all attached files to resources.';