<?php
require_once (dirname(__DIR__) . '/fileitem.class.php');
class FileItem_sqlsrv extends FileItem {}