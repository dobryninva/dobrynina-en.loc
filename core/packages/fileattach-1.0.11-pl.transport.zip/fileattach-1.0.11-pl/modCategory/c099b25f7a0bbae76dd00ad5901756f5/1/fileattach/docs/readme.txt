--------------------
FileAttach
--------------------
Author: Vitaly Chekryzhev <13hakta@gmail.com>
--------------------

File attach/upload tool for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/13hakta/FileAttach/issues

Official docs:
http://13hakta.ru/blog/fileattach-en.html (English)
http://13hakta.ru/blog/fileattach.html (Russian)
