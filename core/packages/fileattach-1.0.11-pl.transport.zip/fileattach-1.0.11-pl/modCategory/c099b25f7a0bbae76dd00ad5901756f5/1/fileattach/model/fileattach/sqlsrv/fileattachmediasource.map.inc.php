<?php
$xpdo_meta_map['FileAttachMediaSource']= array (
  'package' => 'fileattach',
  'version' => '1.1',
  'extends' => 'modMediaSource',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
