<?php

$_lang['perm.fileattach_all'] = 'Manage all files';
$_lang['perm.fileattach_doc'] = 'Manage files in resources';
$_lang['perm.fileattach_download'] = 'Download private files';
$_lang['perm.fileattach_list'] = 'List attached files';
$_lang['perm.fileattach_remove'] = 'Remove attached files';
