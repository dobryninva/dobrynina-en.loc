<?php

$_lang['perm.fileattach_all'] = 'Управление всеми файлами';
$_lang['perm.fileattach_doc'] = 'Управление файлами в документе';
$_lang['perm.fileattach_download'] = 'Скачивать закрытые файлы';
$_lang['perm.fileattach_list'] = 'Листать прикреплённые файлы';
$_lang['perm.fileattach_remove'] = 'Удалять прикрепленные файлы';
