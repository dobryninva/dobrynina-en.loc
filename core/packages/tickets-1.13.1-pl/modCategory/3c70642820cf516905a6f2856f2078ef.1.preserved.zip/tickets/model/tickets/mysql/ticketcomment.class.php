<?php
require_once (dirname(__DIR__) . '/ticketcomment.class.php');
class TicketComment_mysql extends TicketComment {}