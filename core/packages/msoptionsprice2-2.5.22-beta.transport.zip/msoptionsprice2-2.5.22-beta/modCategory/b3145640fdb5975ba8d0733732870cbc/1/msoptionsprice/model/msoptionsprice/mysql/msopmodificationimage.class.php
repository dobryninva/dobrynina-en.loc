<?php
require_once (dirname(__DIR__) . '/msopmodificationimage.class.php');
class msopModificationImage_mysql extends msopModificationImage {}