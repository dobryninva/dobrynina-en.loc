<?php


// header

$_lang['mssetincart_header_id'] = '<i class="icon icon-sort-numeric-desc"></i>';
$_lang['mssetincart_header_rid'] = '<i class="icon icon-folder-o"></i>';
$_lang['mssetincart_header_actions'] = '<i class="icon icon-cogs"></i>';

// tooltip

$_lang['mssetincart_tooltip_id'] = 'Id';
$_lang['mssetincart_tooltip_rid'] = 'Id resource';
$_lang['mssetincart_tooltip_type'] = 'Type';

// fields

$_lang['mssetincart_id'] = 'Id';
$_lang['mssetincart_name'] = 'Name';
$_lang['mssetincart_key'] = 'Key';

// tabs
