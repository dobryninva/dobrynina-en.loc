--------------------
msSetInCart
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------
