<?php

/* Errors */

$_lang['mssetincart_err_system'] = 'Системная ошибка';
$_lang['mssetincart_err_unknown'] = 'Неизвестная ошибка';
