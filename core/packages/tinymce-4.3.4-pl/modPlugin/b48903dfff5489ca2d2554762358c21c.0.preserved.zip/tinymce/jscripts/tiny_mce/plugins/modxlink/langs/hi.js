tinyMCE.addI18n('hi.modxlink',{
    link_desc:"Insert/edit link"
});