tinyMCE.addI18n('da.modxlink',{
    link_desc:"Insert/edit link"
});