<?php
require_once (dirname(dirname(__FILE__)) . '/migxformtab.class.php');
class migxFormtab_mysql extends migxFormtab {}