<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'RvgVideos',
    1 => 'RvgVideosTags',
  ),
);