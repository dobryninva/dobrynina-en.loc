<?php
class RvgVideosTags extends xPDOSimpleObject {}