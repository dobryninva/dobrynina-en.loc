<?php

$_lang['looked_prop_limit'] = 'Limiting the output reads on the page.';
$_lang['looked_prop_templates'] = 'ID patterns, separated by commas, where you have to take into account the views. If empty - take into account everywhere, provided that the snippet [[addLooked]] is invoked in each template.';

$_lang['looked_prop_ids'] = 'If "Yes", the snippet returns ID View resources.';
$_lang['looked_prop_tpl'] = 'Chunk design of each item.';
$_lang['looked_prop_tplOuter'] = 'Chunk wrapper entire block.';
$_lang['looked_prop_snippet'] = 'What snippet used to display the results.';
$_lang['looked_prop_sortdir'] = 'Sorting direction.';
$_lang['looked_prop_sortby'] = 'Any resource box for sorting.';
$_lang['looked_prop_parents'] = 'ID of the parent.';
