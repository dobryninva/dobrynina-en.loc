<?php

$_lang['looked_title'] = 'You watched';
$_lang['looked_remove_lokeed'] = 'Remove';
$_lang['looked_remove_all_lokeed'] = 'Remove all';

$_lang['looked_err_empty_snippet'] = 'The mentioned snippet is not found -';