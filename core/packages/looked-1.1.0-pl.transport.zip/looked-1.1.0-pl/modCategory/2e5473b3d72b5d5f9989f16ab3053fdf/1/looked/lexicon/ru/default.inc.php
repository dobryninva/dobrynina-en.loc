<?php

$_lang['looked_title'] = 'Вы смотрели';
$_lang['looked_remove_lokeed'] = 'Удалить';
$_lang['looked_remove_all_lokeed'] = 'Удалить всё';

$_lang['looked_err_empty_snippet'] = 'Указанный сниппет не найден -';
