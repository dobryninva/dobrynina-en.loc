--------------------
Looked
--------------------
Author: Marat Marabar <marat@marabar.ru>
--------------------

Looked for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/Marabar/Looked/issues