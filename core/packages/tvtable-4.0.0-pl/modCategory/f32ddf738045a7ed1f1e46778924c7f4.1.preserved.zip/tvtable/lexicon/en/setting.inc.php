<?php

$_lang['area_tvtable_main'] = 'Main settings';
$_lang['setting_tvtable_clear_button'] = 'Show clearing table button';
$_lang['setting_tvtable_clear_button_desc'] = 'Display the clearing table button.';
$_lang['setting_tvtable_remove_confirm'] = 'Confirmation before removing rows, columns and clearing data';
$_lang['setting_tvtable_remove_confirm_desc'] = 'If you select it, you will be asked to confirm the deletion of data';