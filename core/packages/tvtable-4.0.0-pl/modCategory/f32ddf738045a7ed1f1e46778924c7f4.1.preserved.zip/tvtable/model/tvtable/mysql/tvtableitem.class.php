<?php
require_once(dirname(dirname(__FILE__)) . '/tvtableitem.class.php');

class TVTableItem_mysql extends TVTableItem
{
}