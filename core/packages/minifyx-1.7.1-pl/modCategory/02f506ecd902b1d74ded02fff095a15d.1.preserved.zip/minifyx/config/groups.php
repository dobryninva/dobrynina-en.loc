<?php

return array(
    /*'baseCss' => [
      '[[+assets_url]]style1.css',
      '{assets_url}style2.css'
    ],
    'someJs' => [
        ...
    ]*/
);