<?php

require_once(dirname(dirname(__FILE__)) . '/mspayment.class.php');
class msPayment_mysql extends msPayment
{
}
