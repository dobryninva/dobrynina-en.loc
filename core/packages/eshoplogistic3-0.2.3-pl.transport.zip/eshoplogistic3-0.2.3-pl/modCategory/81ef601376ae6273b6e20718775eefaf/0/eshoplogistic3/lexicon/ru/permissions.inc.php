<?php
/**
 * English permissions Lexicon Entries for eshoplogistic3
 *
 * @package eshoplogistic3
 * @subpackage lexicon
 */
//$_lang['eshoplogistic3_save'] = 'Разрешает создание/изменение данных.';