<?php

$_lang['eshoplogistic3_prop_tpl'] = 'Чанк оформления';
$_lang['eshoplogistic3_prop_city'] = 'Название населённого пункта';
$_lang['eshoplogistic3_prop_fias'] = 'ФИАС-код населённого пункта';
$_lang['eshoplogistic3_prop_widget_key'] = 'Ключ виджета. Указан в настройках виджета в кабинете eShopLogistic';
$_lang['eshoplogistic3_prop_product_id'] = 'Идентификатор товара. По умолчанию - текущий ресурс';
$_lang['eshoplogistic3_prop_options'] = 'Опции товара, которые нужно учитывать при отправке заказа. Через запятую, например: size,color';
