<?php

$_lang['eshoplogistic3_prop_tpl'] = 'Checkout chunk';
$_lang['eshoplogistic3_prop_city'] = 'Name of the settlement';
$_lang['eshoplogistic3_prop_fias'] = 'FIAS-code of the settlement';
$_lang['eshoplogistic3_prop_widget_key'] = 'Widget key. Specified in the widget settings in the eShopLogistic account';
$_lang['eshoplogistic3_prop_product_id'] = 'Product ID. Default - current resource';
$_lang['eshoplogistic3_prop_options'] = 'Item options to consider when submitting an order. Separate by comma, for example: size,color';