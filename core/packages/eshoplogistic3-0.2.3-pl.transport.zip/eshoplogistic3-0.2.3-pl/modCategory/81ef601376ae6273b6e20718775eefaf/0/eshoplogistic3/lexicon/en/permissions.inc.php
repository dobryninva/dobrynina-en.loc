<?php
/**
 * Russian permissions Lexicon Entries for eshoplogistic3
 *
 * @package eshoplogistic3
 * @subpackage lexicon
 */
#$_lang['eshoplogistic3_save'] = 'Permission for save/update data.';