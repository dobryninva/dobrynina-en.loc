<?php
class cgGroup extends xPDOSimpleObject {}