<?php
require_once (dirname(__DIR__) . '/sxqueue.class.php');
class sxQueue_mysql extends sxQueue {}