<?php

$_lang['area_sendex_main'] = 'Основные';

$_lang['setting_sendex_export_fields'] = 'Поля для экспорта';
$_lang['setting_sendex_export_fields_desc'] = 'Введите данные через запятую. Доступные значения: id,user_id,email,username,fullname,phone,mobilephone';
$_lang['setting_sendex_hide_export_button'] = 'Скрыть кнопку экспорта';
$_lang['setting_sendex_hide_export_button_desc'] = 'Отключает кнопку экспорта списка email адресов в рассылке';
