<?php
require_once (dirname(__DIR__) . '/sxsubscriber.class.php');
class sxSubscriber_mysql extends sxSubscriber {}