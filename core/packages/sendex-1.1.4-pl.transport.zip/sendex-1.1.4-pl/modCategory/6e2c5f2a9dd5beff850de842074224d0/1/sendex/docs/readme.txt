--------------------
Sendex
--------------------
Author: Vasily Naumkin <bezumkin@yandex.ru>
--------------------

Sendex is a simple subscriptions component for MODX Revolution.

Documentation:
https://docs.modx.pro/komponentyi/sendex

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/bezumkin/Sendex