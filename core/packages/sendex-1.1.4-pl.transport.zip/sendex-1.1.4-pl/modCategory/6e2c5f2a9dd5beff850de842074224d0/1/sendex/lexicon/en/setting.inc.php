<?php

$_lang['area_sendex_main'] = 'Main';

$_lang['setting_sendex_export_fields'] = 'Fields for export';
$_lang['setting_sendex_export_fields_desc'] = 'Enter fields separated by commas. Available values: id,user_id,email,username,fullname,phone,mobilephone';
$_lang['setting_sendex_hide_export_button'] = 'Hide export button';
$_lang['setting_sendex_hide_export_button_desc'] = 'Disables the button to export the list of email addresses in the mailing list';
