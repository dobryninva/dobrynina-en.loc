<?php
require_once (dirname(__DIR__) . '/sxnewsletter.class.php');
class sxNewsletter_mysql extends sxNewsletter {}