-------------------------------------------------------
Extension: ResVideoGallery for MODX Revolution 2.4.2-pl
-------------------------------------------------------
Version: 1.0.0-beta
Released: June 04, 2016
Since: June 04, 2016
Author: Prihod

Description
    ResVideoGallery