<?php
require_once (dirname(dirname(__FILE__)) . '/rvgvideos.class.php');
class RvgVideos_mysql extends RvgVideos {}