<?php
require_once (dirname(dirname(__FILE__)) . '/rvgvideostags.class.php');
class RvgVideosTags_mysql extends RvgVideosTags {}