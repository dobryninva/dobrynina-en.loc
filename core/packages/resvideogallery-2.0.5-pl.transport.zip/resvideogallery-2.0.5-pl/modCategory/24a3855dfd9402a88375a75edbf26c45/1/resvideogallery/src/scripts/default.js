//= partials/plugins/lightcase.js
//= partials/plugins/jquery.serializeObject.js
//= partials/plugins/plyr/i18n.js
//= partials/plugins/plyr/plyr.js
//= partials/common.js