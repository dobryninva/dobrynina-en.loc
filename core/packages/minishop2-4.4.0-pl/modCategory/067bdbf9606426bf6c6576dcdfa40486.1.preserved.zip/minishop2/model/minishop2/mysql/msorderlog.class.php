<?php

require_once(dirname(__FILE__, 2) . '/msorderlog.class.php');

class msOrderLog_mysql extends msOrderLog
{
}
