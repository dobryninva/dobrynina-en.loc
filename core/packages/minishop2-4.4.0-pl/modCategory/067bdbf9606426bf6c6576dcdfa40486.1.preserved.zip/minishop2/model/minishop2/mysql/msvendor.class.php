<?php

require_once(dirname(__FILE__, 2) . '/msvendor.class.php');

class msVendor_mysql extends msVendor
{
}
