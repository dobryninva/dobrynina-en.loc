<?php

require_once(dirname(__FILE__, 2) . '/msorderaddress.class.php');

class msOrderAddress_mysql extends msOrderAddress
{
}
