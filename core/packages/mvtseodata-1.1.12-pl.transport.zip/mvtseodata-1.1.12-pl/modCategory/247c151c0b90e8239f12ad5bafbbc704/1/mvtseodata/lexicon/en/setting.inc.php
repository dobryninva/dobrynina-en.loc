<?php

$_lang['area_mvtseodata_main'] = 'Основные';

$_lang['setting_mvtseodata_product_indexing_where'] = 'Дополнительное условие выборки товаров при индексировании';
$_lang['setting_mvtseodata_product_indexing_where_desc'] = 'JSON. Фильтрация по объекту msProductData. Например: {"discontinued":0}';
$_lang['setting_mvtseodata_mng_rt'] = 'Использовать текстовый редактор для контента';
$_lang['setting_mvtseodata_mng_rt_desc'] = '';
$_lang['setting_mvtseodata_resource_emty_fields'] = 'Заменять пустые поля ресурса';
$_lang['setting_mvtseodata_resource_emty_fields_desc'] = 'Заменять ли пустые значения полей ресурса значением из компонента, если установлен приоритет ресурса.';
$_lang['setting_mvtseodata_component_emty_fields'] = 'Заменять пустые поля компонента';
$_lang['setting_mvtseodata_component_emty_fields_desc'] = 'Заменять ли пустые значения полей компонента значением из ресурса, если установлен приоритет компонента.';