<?php
class mvtSeoDataCatogories extends xPDOSimpleObject {}