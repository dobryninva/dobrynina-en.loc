<?php

/**
 * @package mvtseodata
 */
class mvtSeoDataItem extends xPDOSimpleObject
{
}