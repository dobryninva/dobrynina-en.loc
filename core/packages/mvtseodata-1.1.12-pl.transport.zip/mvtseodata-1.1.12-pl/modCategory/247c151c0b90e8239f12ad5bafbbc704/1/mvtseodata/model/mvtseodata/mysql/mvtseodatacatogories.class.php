<?php
require_once (dirname(__DIR__) . '/mvtseodatacatogories.class.php');
class mvtSeoDataCatogories_mysql extends mvtSeoDataCatogories {}