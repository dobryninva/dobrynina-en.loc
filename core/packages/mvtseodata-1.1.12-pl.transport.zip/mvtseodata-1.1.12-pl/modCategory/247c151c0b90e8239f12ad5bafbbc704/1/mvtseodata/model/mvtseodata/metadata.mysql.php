<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'mvtSeoDataCatogories',
    1 => 'mvtSeoDataTemplates',
  ),
);