<?php
class mvtSeoDataTemp extends xPDOSimpleObject {}