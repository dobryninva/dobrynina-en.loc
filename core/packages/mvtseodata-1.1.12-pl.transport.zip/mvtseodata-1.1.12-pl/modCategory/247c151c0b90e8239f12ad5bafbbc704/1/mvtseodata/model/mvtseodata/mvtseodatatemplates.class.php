<?php
class mvtSeoDataTemplates extends xPDOSimpleObject {}