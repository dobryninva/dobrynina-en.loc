<?php
require_once (dirname(__DIR__) . '/mvtseodatatemplates.class.php');
class mvtSeoDataTemplates_mysql extends mvtSeoDataTemplates {}