--------------------
MobileDetect
--------------------
Author: Vasily Naumkin <bezumkin@yandex.ru>
--------------------

The MobileDetect output filter for Fenom and MODX.