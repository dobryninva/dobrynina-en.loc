<?php

$_lang['md_prop_input'] = 'Тип устройста для проверки Standard, Tablet или Mobile';