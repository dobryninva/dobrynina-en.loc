<?php
require_once (dirname(__DIR__) . '/mseword.class.php');
class mseWord_mysql extends mseWord {}