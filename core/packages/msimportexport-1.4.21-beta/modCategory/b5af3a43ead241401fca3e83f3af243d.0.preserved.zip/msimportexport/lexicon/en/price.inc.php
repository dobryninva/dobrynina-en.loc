<?php
/**
 * Price English Lexicon Entries for msImportExport
 *
 * @package msimportexport
 * @subpackage lexicon
 */
$_lang['msie.download_price'] = 'Download Price List';
$_lang['msie.err.sig'] = 'Invalid request signature';
$_lang['msie.err.timeout'] = 'You can not download the price list more often than %s seconds.';