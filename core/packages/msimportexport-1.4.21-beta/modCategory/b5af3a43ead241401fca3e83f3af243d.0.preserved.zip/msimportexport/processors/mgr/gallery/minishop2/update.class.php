<?php
include_once MODX_CORE_PATH . 'components/minishop2/processors/mgr/gallery/update.class.php';
class msImportExportGalleryUpdateProcessor extends msProductFileUpdateProcessor
{

}

return 'msImportExportGalleryUpdateProcessor';