<?php
require_once (dirname(dirname(__FILE__)) . '/msieheadalias.class.php');
class MsieHeadAlias_mysql extends MsieHeadAlias {}