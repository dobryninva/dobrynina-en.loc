<?php

namespace OzdemirBurak\Iris\Exceptions;

class InvalidColorException extends \Exception
{

}
