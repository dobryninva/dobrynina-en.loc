<?php

namespace OzdemirBurak\Iris\Exceptions;

class AmbiguousColorString extends \Exception
{

}
