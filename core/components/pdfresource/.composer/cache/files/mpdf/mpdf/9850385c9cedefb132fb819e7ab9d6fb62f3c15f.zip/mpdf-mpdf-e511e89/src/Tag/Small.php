<?php

namespace Mpdf\Tag;

class Small extends InlineTag
{


}
